package com.example.lucas01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnCalcular = (Button)this.findViewById(R.id.btnCalcular);
        Button btnLimpar = (Button)this.findViewById(R.id.btnLimpar);
        EditText edtTexto = (EditText)this.findViewById(R.id.edtTexto);
        TextView txvLabel2 = (TextView)this.findViewById(R.id.txvLabel2);
        Button btnContar = (Button)this.findViewById(R.id.btnContar);

        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtTexto.setText("");
                txvLabel2.setText("");
            }
        });

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String texto = edtTexto.getText().toString();
                int tamanho = texto.length();
                txvLabel2.setText(String.valueOf(tamanho).toString());
            }
        });
        int contador = 0;
        int contadorDeA = 0;
        while(contador <= edtTexto.length()){
            if(edtTexto[contador] == "a"){

            }



    }
}
}